# Dash Animator for Ubuntu

This is a Gnome Shell extension that animates the Ubuntu Dock, or more precisely, the Dash-to-Dock extension.

This works with other distribution using Dash-to-Dock extensions.


Check out also Dash2Dock lite which is a total replacement of Dash-to-Dock. It is also animated:
https://github.com/icedman/dash2dock-lite
