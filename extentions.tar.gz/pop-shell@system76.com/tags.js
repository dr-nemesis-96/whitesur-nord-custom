var Tiled = 0;
var Floating = 1;
var Blocked = 2;
var ForceTile = 3;
